`timescale 1ns/1ps
module tb_not;
  reg [3:0] a, b;
  reg cin;
  wire [3:0] x;
  integer ia, ib, ic, k, expected, remainder, distance, fill, overflow, count;
  alu_not dut(.a(a), .x(x));
  initial begin
    $dumpfile("build/not.vcd");
    $dumpvars(0, dut);
    count=0;
    for (ia=0; ia<16; ia=ia+1)
      for (ib=0; ib<1; ib=ib+1)
        for (ic=0; ic<1; ic=ic+1) begin
          a=ia; b=ib; cin=ic; #10;
          expected = 0;
          for (k=0; k<4; k=k+1)
            expected = expected | (((3 >> (2*((ia>>k)&1)+((ib>>k)&1))) & 1) << k);
          if (x !== expected[3:0]) $fatal(1,"not a=%d b=%d",ia,ib);
          count=count+1;
        end
    $display("PASS not: %0d cases",count);
    $finish;
  end
endmodule
